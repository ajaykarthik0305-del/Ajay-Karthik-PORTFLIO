AJAY S — PROFESSIONAL PORTFOLIO V2

Open index.html in a browser or VS Code Live Server.

Upgrades:
- Recruiter-first hero section
- Career focus / Open to opportunities
- Core capabilities section
- Experience timeline
- Proof-of-work projects
- Achievements section
- Certificate section
- Resume PDF + Portfolio Summary PDF
- Functional mailto contact enquiry form
- Mobile responsive navigation
- LinkedIn, phone, email and download actions

Folders:
assets/     profile photo + certificate
documents/  resume PDFs/DOCX + interactive project files
